from django.contrib import admin
from . import models


admin.site.register(models.ConatctModel)
admin.site.register(models.UserContactModel)