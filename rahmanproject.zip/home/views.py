from django.shortcuts import render
from django.views.generic import View
from contact.models import ConatctModel
from oils.models import ProductModel
from aboutus.models import AboutusModel
from home.models import Logo


logo = Logo.objects.all()
product = ProductModel.objects.all()
contact = ConatctModel.objects.all()
about = AboutusModel.objects.all()

class HomeView(View):
    def get(self, request):
        return render(request, 'home/index.html', {'product':product, 'contact':contact, 'about':about, 'logo':logo})
